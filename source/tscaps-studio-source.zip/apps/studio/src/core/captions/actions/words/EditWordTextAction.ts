import type { CaptionsTextEditTelemetryReporter } from '@core/captions/services/CaptionsTextEditTelemetryReporter';
import { DocumentEditor } from '@tscaps/engine';
import type { EditorStore } from '@core/editor/store/EditorStore';
import type { DocumentDeriver } from '@core/editor/services/DocumentDeriver';

const docEditor = new DocumentEditor();

// Updates a word's text in the document without re-running the splitter
// pipeline. Splits on whitespace if the new text contains multiple words.
// Effects are reapplied so time-shaping passes (e.g. gap-free padding)
// re-stamp against the post-edit word boundaries.
export class EditWordTextAction {
  constructor(
    private readonly store: EditorStore,
    private readonly deriver: DocumentDeriver,
    private readonly textEditReporter: CaptionsTextEditTelemetryReporter,
  ) {}

  execute(wordId: string, text: string): void {
    const snap = this.store.snapshot();
    const document = snap.document;
    if (!document) return;

    const pos = docEditor.findWordById(document, wordId);
    if (!pos) return;

    const original = document.getSegments()[pos.segIdx]!.lines[pos.lineIdx]!.words[pos.wordIdx]!;
    const newWords = docEditor.computeWordTextSplit(original, text);
    const edited = docEditor.replaceWordAt(document, pos.segIdx, pos.lineIdx, pos.wordIdx, newWords);
    const retagged = this.deriver.retag(edited);
    const next = this.deriver.reapplyEffects(retagged, snap.sheets, snap.video.duration, snap.decorationOverrides);

    this.store.commit();
    this.store.patch({ document: next });
    this.textEditReporter.report('word-text');
  }
}
